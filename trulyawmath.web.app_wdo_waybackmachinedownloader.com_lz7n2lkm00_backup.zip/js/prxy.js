/************************
 * Prxy-only script
 * Split from script.js
 ************************/

// === SCRAMJET PRXY ===
let sjTabs = [];
let sjActiveTabId = 1;
let sjNextTabId = 2;

const { ScramjetController } = $scramjetLoadController();
const scramjet = new ScramjetController({
  files: {
    wasm: "/scram/scramjet.wasm.wasm",
    all: "/scram/scramjet.all.js",
    sync: "/scram/scramjet.sync.js"
  },
});
scramjet.init();

// Register service worker correctly
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js")
    .then(() => console.log("Prxy SW registered"))
    .catch(err => console.error("SW failed", err));
}

const sjConnection = new BareMux.BareMuxConnection("/baremux/worker.js");
sjConnection.setTransport("/epoxy/index.mjs", [{ wisp: "wss://gointospace.app/wisp/" }]);

function sjCreateTab(url = "https://start.duckduckgo.com/") {
  const frame = scramjet.createFrame();
  frame.frame.classList.add("prxy-frame");

  const tab = {
    id: sjNextTabId++,
    title: "New Tab",
    url,
    frame,
  };

  frame.frame.src = "/newtab.html";
  frame.addEventListener("urlchange", (e) => {
    if (!e.url) return;
    tab.url = e.url;
    try {
      tab.title = frame.frame.contentWindow?.document?.title || new URL(e.url).hostname;
    } catch {
      tab.title = new URL(e.url).hostname || "...";
    }
    sjUpdateTabsUI();
    document.getElementById("prxyAddress").value = tab.url;
  });

  sjTabs.push(tab);
  document.getElementById("prxyIframes").appendChild(frame.frame);
  sjSwitchTab(tab.id);
}

function sjSwitchTab(id) {
  sjTabs.forEach((t) => t.frame.frame.classList.add("hidden"));
  sjActiveTabId = id;
  const active = sjTabs.find((t) => t.id === id);
  if (active) active.frame.frame.classList.remove("hidden");
  sjUpdateTabsUI();
  document.getElementById("prxyAddress").value = active?.url || "";
}

function sjCloseTab(id) {
  const i = sjTabs.findIndex((t) => t.id === id);
  if (i === -1) return;
  const tab = sjTabs[i];
  tab.frame.frame.remove();
  sjTabs.splice(i, 1);
  if (sjTabs.length) sjSwitchTab(sjTabs[0].id);
  else sjCreateTab();
}

function sjUpdateTabsUI() {
  const c = document.getElementById("prxyTabs");
  c.innerHTML = "";
  sjTabs.forEach((t) => {
    const el = document.createElement("div");
    el.className = "prxy-tab" + (t.id === sjActiveTabId ? " active" : "");
    el.textContent = t.title;
    el.onclick = () => sjSwitchTab(t.id);
    const close = document.createElement("button");
    close.textContent = "×";
    close.onclick = (e) => { e.stopPropagation(); sjCloseTab(t.id); };
    el.appendChild(close);
    c.appendChild(el);
  });
  const add = document.createElement("button");
  add.textContent = "+";
  add.onclick = () => sjCreateTab();
  c.appendChild(add);
}

function handlePrxySubmit() {
  const active = sjTabs.find((t) => t.id === sjActiveTabId);
  if (!active) return;
  let url = document.getElementById("prxyAddress").value.trim();
  if (!url.startsWith("http")) url = "https://" + url;
  active.url = url;
  active.frame.go(url);
}

function getActiveTab() {
  return sjTabs.find((t) => t.id === sjActiveTabId);
}

// init
window.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("prxy")) {
    sjCreateTab();
  }
});
