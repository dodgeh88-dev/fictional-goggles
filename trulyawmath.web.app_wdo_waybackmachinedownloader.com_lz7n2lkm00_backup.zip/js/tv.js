let allChannels = [];
let currentSchedule = null;
window.currentArt = null;

// === LOAD CHANNELS ===
async function loadChannels() {
  try {
    const res = await fetch('https://somestuffserver.koyeb.app/api/m3u8list');
    const text = await res.text();
    const lines = text.split('\n');

    allChannels = [];
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith('#EXTINF')) {
        const title = lines[i].split(',').pop().trim();
        const logoMatch = lines[i].match(/tvg-logo="(.*?)"/);
        const logo = logoMatch ? logoMatch[1] : '';
        const stream = lines[i + 1]?.trim();
        if (stream) allChannels.push({ title, logo, stream });
      }
    }

    renderChannels(allChannels);
    fetchSchedule();
  } catch (err) {
    console.error("Failed to load channels:", err);
  }
}

// === RENDER CHANNEL CARDS ===
function renderChannels(channels) {
  const container = document.getElementById('channelGrid');
  if (!container) return;
  container.innerHTML = '';

  channels.forEach(channel => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <img src="${channel.logo}" alt="${channel.title}" />
      <h3>${channel.title}</h3>
      <div class="schedule" id="sched-${channel.title}">Loading schedule...</div>
      <button class="watch-btn">Watch</button>
    `;
    container.appendChild(card);

    const btn = card.querySelector('.watch-btn');
    btn.addEventListener('click', () => openPlayer(channel.stream, channel.title, channel.logo));
  });
}

// === FETCH SCHEDULE ===
async function fetchSchedule() {
  try {
    const res = await fetch(
      'https://somestuffserver.koyeb.app/api/scrape?url=https://tvpass.org/tv_schedules/channels_tv_schedule.json'
    );
    const data = await res.json();

    allChannels.forEach(channel => {
      const match = data.find(d =>
        d.title && d.title.toLowerCase().includes(channel.title.toLowerCase())
      );
      if (match && match.next_programs) {
        const el = document.getElementById('sched-' + channel.title);
        const now = new Date();
        const current = match.next_programs.find(p => {
          const start = new Date(p['data-listdatetime']);
          const end = new Date(start.getTime() + p['data-duration'] * 60000);
          return start <= now && now < end;
        });
        if (current) {
          const end = new Date(new Date(current['data-listdatetime']).getTime() + current['data-duration'] * 60000);
          el.innerHTML = `<strong>${current['data-showname']}</strong><br><small>Until ${end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>`;
        }
      }
    });

    window.fullScheduleData = data;
  } catch (err) {
    console.error("Failed to fetch schedule:", err);
  }
}

// === OPEN PLAYER ===
function openPlayer(streamUrl, channelTitle, logoUrl) {
  document.getElementById('mainPage').style.display = 'none';
  document.getElementById('playerModal').style.display = 'flex';

  const playerContainer = document.getElementById('player');
  playerContainer.innerHTML = '';

  if (window.currentArt && typeof window.currentArt.destroy === 'function') {
    window.currentArt.destroy();
    window.currentArt = null;
  }

  window.currentArt = new Artplayer({
    container: '#player',
    url: streamUrl,
    isLive: true,
    autoplay: true,
    fullscreenWeb: true,
    volume: 1.0,
    poster: logoUrl,
    type: 'm3u8',
    plugins: [
      artplayerPluginHlsControl({
        defaultQuality: 'auto',
        defaultAudio: 'auto',
        quality: { control: true, setting: true, getName: l => l.height + 'P', auto: 'Auto' },
        audio: { control: true, setting: true, getName: t => t.name, auto: 'Auto' },
      }),
    ],
    customType: {
      m3u8: function (video, url, art) {
        if (Hls.isSupported()) {
          if (art.hls) art.hls.destroy();
          const hls = new Hls();
          hls.loadSource(url);
          hls.attachMedia(video);
          art.hls = hls;
          art.on('destroy', () => hls.destroy());

          const offset = 8;
          const seekToLive = () => {
            if (!isNaN(video.duration)) {
              video.currentTime = Math.max(video.duration - offset, 0);
              video.removeEventListener('play', seekToLive);
            }
          };
          video.addEventListener('play', seekToLive, { once: true });
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = url;
        }
      },
    },
  });

  document.getElementById('playerTitle').textContent = 'Now Playing - ' + channelTitle;

  if (window.fullScheduleData) {
    const match = window.fullScheduleData.find(d =>
      d.title && d.title.toLowerCase().includes(channelTitle.toLowerCase())
    );
    currentSchedule = match && match.next_programs ? match.next_programs : null;
    renderScheduleSidebar(currentSchedule || []);
  }

  document.getElementById('scheduleSidebar').style.display = 'none';
}

// === CLOSE PLAYER ===
function closePlayer() {
  document.getElementById('playerModal').style.display = 'none';
  document.getElementById('mainPage').style.display = 'block';
  document.getElementById('player').innerHTML = '';
  document.getElementById('scheduleSidebar').style.display = 'none';
}

// === SCHEDULE SIDEBAR ===
function toggleSchedule() {
  const sidebar = document.getElementById('scheduleSidebar');
  sidebar.style.display = sidebar.style.display === 'none' ? 'block' : 'none';
}
function closeSchedule() {
  document.getElementById('scheduleSidebar').style.display = 'none';
}
function renderScheduleSidebar(schedule) {
  const content = document.getElementById('scheduleContent');
  if (!schedule || schedule.length === 0) {
    content.innerHTML = '<h3>Upcoming</h3><div>No schedule available.</div>';
    return;
  }
  content.innerHTML = '<h3>Upcoming</h3>' + schedule.map(p =>
    `<div style="margin-bottom:1rem;"><strong>${p['data-showname']}</strong><br><small>${new Date(p['data-listdatetime']).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} – ${new Date(new Date(p['data-listdatetime']).getTime() + p['data-duration'] * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small><br>${p['data-episodetitle'] || ''}</div>`
  ).join('');
}

// === FILTER & VIEW TOGGLE ===
document.getElementById('searchBox').addEventListener('input', e => {
  const query = e.target.value.toLowerCase();
  const filtered = allChannels.filter(ch => ch.title.toLowerCase().includes(query));
  renderChannels(filtered);
});
document.getElementById('viewToggle').addEventListener('change', e => {
  const grid = document.getElementById('channelGrid');
  grid.style.display = e.target.value === 'list' ? 'block' : 'grid';
});

// === INIT ===
document.getElementById('scheduleCloseBtn').addEventListener('click', closeSchedule);
loadChannels();
